package com.example.sparkysadvancedauto;

import androidx.annotation.NonNull;
import android.view.View;

public interface ClickListener {
    void onClick(@NonNull View view, int position);
    void onLongClick(@NonNull View view, int position);
}
