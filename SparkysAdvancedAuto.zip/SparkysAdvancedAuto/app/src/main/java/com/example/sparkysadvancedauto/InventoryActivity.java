package com.example.sparkysadvancedauto;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private final DatabaseHelper databaseHelper = new DatabaseHelper(this);
    private final List<InventoryItem> inventoryItems = new ArrayList<>();
    private InventoryAdapter adapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load inventory data from database
        loadInventoryFromDatabase();

        // Set up adapter with the inventory data
        adapter = new InventoryAdapter(inventoryItems);
        recyclerView.setAdapter(adapter);

        // Set up long-click listener to delete an item
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(this, recyclerView, new ClickListener() {
            @Override
            public void onClick(@NonNull View view, int position) {
                // Normal click event
            }

            @Override
            public void onLongClick(@NonNull View view, int position) {
                // Delete the item from the database
                databaseHelper.deleteItem(position + 1);  // Assuming position matches id in the database

                // Remove the item from the list and update the adapter
                inventoryItems.remove(position);
                adapter.notifyItemRemoved(position);

                Toast.makeText(InventoryActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
            }
        }));

        // Set up button listeners
        findViewById(R.id.button_add_item).setOnClickListener(v -> addItem());
        findViewById(R.id.button_save_inventory).setOnClickListener(v -> saveInventory());
        findViewById(R.id.button_modify_inventory).setOnClickListener(v -> enableInventoryEditing());

        // Set up back button for logging out and going back to login screen
        Button backButton = findViewById(R.id.button_back);
        backButton.setOnClickListener(v -> logOutAndGoBack());
    }

    private void loadInventoryFromDatabase() {
        Cursor cursor = databaseHelper.getAllItems();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String sku = cursor.getString(1);
                String category = cursor.getString(2);
                String name = cursor.getString(3);
                int inStock = cursor.getInt(4);
                InventoryItem item = new InventoryItem(sku, category, name, inStock);
                inventoryItems.add(item);
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }
    }

    private void addItem() {
        String sku = "123456";
        String category = "Tires";
        String name = "New Tire Model";
        int inStock = 15;

        databaseHelper.addItem(sku, category, name, inStock);
        InventoryItem newItem = new InventoryItem(sku, category, name, inStock);
        inventoryItems.add(newItem);

        adapter.notifyItemInserted(inventoryItems.size() - 1);

        Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
    }

    private void saveInventory() {
        // Loop through each item in the RecyclerView and save updated values
        for (int i = 0; i < inventoryItems.size(); i++) {
            RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForAdapterPosition(i);
            if (viewHolder instanceof InventoryAdapter.InventoryViewHolder) {
                InventoryAdapter.InventoryViewHolder itemViewHolder = (InventoryAdapter.InventoryViewHolder) viewHolder;

                // Get the updated values from the EditText fields
                String sku = itemViewHolder.skuEditText.getText().toString();
                String category = itemViewHolder.categoryEditText.getText().toString();
                String name = itemViewHolder.nameEditText.getText().toString();
                int inStock = Integer.parseInt(itemViewHolder.inStockEditText.getText().toString());

                // Update the inventory item in the list
                InventoryItem updatedItem = new InventoryItem(sku, category, name, inStock);
                inventoryItems.set(i, updatedItem);

                // Save to the database
                databaseHelper.updateItem(i + 1, sku, category, name, inStock);  // Assume i+1 is the item ID
            }
        }

        Toast.makeText(this, "Inventory saved", Toast.LENGTH_SHORT).show();

        // Disable modification after saving
        disableInventoryEditing();
    }

    private void enableInventoryEditing() {
        // Enable editing for all fields
        for (int i = 0; i < inventoryItems.size(); i++) {
            RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForAdapterPosition(i);
            if (viewHolder instanceof InventoryAdapter.InventoryViewHolder) {
                InventoryAdapter.InventoryViewHolder itemViewHolder = (InventoryAdapter.InventoryViewHolder) viewHolder;

                itemViewHolder.skuEditText.setEnabled(true);
                itemViewHolder.categoryEditText.setEnabled(true);
                itemViewHolder.nameEditText.setEnabled(true);
                itemViewHolder.inStockEditText.setEnabled(true);
            }
        }
    }

    private void disableInventoryEditing() {
        // Disable editing for all fields
        for (int i = 0; i < inventoryItems.size(); i++) {
            RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForAdapterPosition(i);
            if (viewHolder instanceof InventoryAdapter.InventoryViewHolder) {
                InventoryAdapter.InventoryViewHolder itemViewHolder = (InventoryAdapter.InventoryViewHolder) viewHolder;

                itemViewHolder.skuEditText.setEnabled(false);
                itemViewHolder.categoryEditText.setEnabled(false);
                itemViewHolder.nameEditText.setEnabled(false);
                itemViewHolder.inStockEditText.setEnabled(false);
            }
        }
    }

    private void logOutAndGoBack() {
        // Clear user session or other user data here if needed
        Intent intent = new Intent(InventoryActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);  // Clears the back stack
        startActivity(intent);
        finish();  // Finish the current activity to prevent going back to it
    }
}
