package com.example.sparkysadvancedauto;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private List<InventoryItem> inventoryList;
    private boolean isEditable = false;

    public InventoryAdapter(List<InventoryItem> inventoryList) {
        this.inventoryList = inventoryList;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.inventory_item, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = inventoryList.get(position);

        // Set EditText values
        holder.skuEditText.setText(item.getSku());
        holder.categoryEditText.setText(item.getCategory());
        holder.nameEditText.setText(item.getName());
        holder.inStockEditText.setText(String.valueOf(item.getInStock()));

        // Make the fields editable or non-editable based on isEditable flag
        holder.skuEditText.setEnabled(isEditable);
        holder.categoryEditText.setEnabled(isEditable);
        holder.nameEditText.setEnabled(isEditable);
        holder.inStockEditText.setEnabled(isEditable);
    }

    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    // Method to update the inventory list (for search functionality)
    public void updateInventoryList(List<InventoryItem> updatedList) {
        this.inventoryList = updatedList;
        notifyItemRangeChanged(0, updatedList.size());  // Optimized notification for range
    }

    // Method to enable or disable editing
    public void enableEditing(boolean enable) {
        this.isEditable = enable;
        notifyItemRangeChanged(0, inventoryList.size());  // Optimized notification for range
    }

    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        public EditText skuEditText, categoryEditText, nameEditText, inStockEditText;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);

            // Find views by their IDs from the XML layout
            skuEditText = itemView.findViewById(R.id.skuEditText);
            categoryEditText = itemView.findViewById(R.id.categoryEditText);
            nameEditText = itemView.findViewById(R.id.nameEditText);
            inStockEditText = itemView.findViewById(R.id.inStockEditText);
        }
    }
}
