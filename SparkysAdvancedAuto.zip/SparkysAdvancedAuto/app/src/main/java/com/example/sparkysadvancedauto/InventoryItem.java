package com.example.sparkysadvancedauto;

@SuppressWarnings("unused")  // Suppress warnings for unused methods
public class InventoryItem {

    private String sku;
    private String category;
    private String name;
    private int inStock;

    public InventoryItem(String sku, String category, String name, int inStock) {
        this.sku = sku;
        this.category = category;
        this.name = name;
        this.inStock = inStock;
    }

    // Getters
    public String getSku() {
        return sku;
    }

    public String getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public int getInStock() {
        return inStock;
    }

    // Setters for future use (e.g., editing items)
    public void setSku(String sku) {
        this.sku = sku;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setInStock(int inStock) {
        this.inStock = inStock;
    }
}
